/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Info
/*     */ {
/*     */   private static final String INFO_FILENAME = "META-INF/jdom-info.xml";
/*     */   final String title;
/*     */   final String version;
/*     */   final String copyright;
/*     */   final String description;
/*     */   final String license;
/*     */   final String support;
/*     */   final String website;
/* 191 */   final List authors = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Info() throws Exception {
/* 202 */     InputStream inputStream = getInfoFileStream();
/*     */     
/* 204 */     SAXBuilder builder = new SAXBuilder();
/*     */ 
/*     */     
/* 207 */     Document doc = builder.build(inputStream);
/* 208 */     Element root = doc.getRootElement();
/*     */     
/* 210 */     this.title = root.getChildTextTrim("title");
/* 211 */     this.version = root.getChildTextTrim("version");
/* 212 */     this.copyright = root.getChildTextTrim("copyright");
/* 213 */     this.description = root.getChildTextTrim("description");
/* 214 */     this.license = root.getChildTextTrim("license");
/* 215 */     this.support = root.getChildTextTrim("support");
/* 216 */     this.website = root.getChildTextTrim("web-site");
/*     */     
/* 218 */     List authorElements = root.getChildren("author");
/* 219 */     for (Iterator iter = authorElements.iterator(); iter.hasNext(); ) {
/* 220 */       Element element = iter.next();
/*     */       
/* 222 */       JDOMAbout.Author author = new JDOMAbout.Author(element.getChildTextTrim("name"), element.getChildTextTrim("e-mail"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 227 */       this.authors.add(author);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream getInfoFileStream() throws FileNotFoundException {
/* 234 */     InputStream inputStream = getClass().getResourceAsStream("META-INF/jdom-info.xml");
/*     */     
/* 236 */     if (inputStream == null) {
/* 237 */       throw new FileNotFoundException("META-INF/jdom-info.xml not found; it should be within the JDOM JAR but wasn't found on the classpath");
/*     */     }
/*     */ 
/*     */     
/* 241 */     return inputStream;
/*     */   }
/*     */ }


/* Location:              /home/andrew/workspace/jNSMR/inst/jNSM/jNSM_v1.6.1_public_bundle/libs/newhall-1.6.1.jar!/JDOMAbout$Info.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */