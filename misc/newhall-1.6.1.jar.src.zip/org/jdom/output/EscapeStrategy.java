package org.jdom.output;

public interface EscapeStrategy {
  boolean shouldEscape(char paramChar);
}


/* Location:              /home/andrew/workspace/jNSMR/inst/jNSM/jNSM_v1.6.1_public_bundle/libs/newhall-1.6.1.jar!/org/jdom/output/EscapeStrategy.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */